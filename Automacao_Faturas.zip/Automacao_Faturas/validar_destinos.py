
from openpyxl import load_workbook
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
ARQUIVO = BASE / "planilhas" / "teste automação.xlsm"
ABA = "COPEL"

# UCs que devem ser preenchidas individualmente.
UCS_INDIVIDUAIS = [
    "000107312903154",
    "000089993503173",
    "000290298603152",
    "000387264403105",
    "000259216303146",
    "000172913003140",
    "000092929903180",
    "000191504303106",
    "000080222403159",
    "000148234203104",
    "000490130003129",
    "000499193203182",
    "000497982103131",
    "000452896103119",
    "000515038503116",
]

CAMERAS = [
    "LT", "MJ", "MZ", "NP", "OF", "OV", "PL", "QB", "QR",
    "RH", "RX", "SN", "TD", "TT", "UJ", "UZ", "VP", "WF",
    "WV", "XL", "YB", "YR",
]

CAMPOS = [
    "DATA", "NOTA FISCAL", "CONTROLE OU FAT",
    "CONSUMO", "CUSTO", "BANDEIRA", "VALOR BANDEIRA",
    "PENALIDADES", "ILUMINAÇÃO PÚBLICA", "VALOR FATURA",
    "COFINS", "CSLL", "IRPJ", "PIS", "VALOR BRUTO",
]

def normalizar(valor):
    if valor is None:
        return ""
    texto = str(valor).strip().upper()
    texto = texto.replace("Ç", "C").replace("Ã", "A")
    texto = texto.replace("Á", "A").replace("É", "E")
    texto = texto.replace("Í", "I").replace("Ó", "O")
    texto = texto.replace("Ú", "U")
    return re.sub(r"\s+", " ", texto)

def localizar_uc(ws, uc):
    # Procura a UC como texto em qualquer célula da planilha.
    alvo = str(uc).strip()
    encontrados = []

    for linha in ws.iter_rows():
        for celula in linha:
            if celula.value is None:
                continue

            valor = str(celula.value).strip()
            if valor == alvo:
                encontrados.append(celula.coordinate)

    return encontrados

def localizar_bloco_camera(ws, sigla):
    # Procura a sigla nas linhas de identificação superiores.
    encontrados = []

    for linha in range(1, 5):
        for coluna in range(1, ws.max_column + 1):
            valor = ws.cell(linha, coluna).value
            if normalizar(valor) == sigla:
                encontrados.append(ws.cell(linha, coluna).coordinate)

    return encontrados

def mostrar_colunas(ws, coluna_inicial):
    # Mostra os cabeçalhos próximos do início do bloco.
    for deslocamento in range(15):
        celula = ws.cell(4, coluna_inicial + deslocamento)
        sub = ws.cell(5, coluna_inicial + deslocamento)

        valor = normalizar(celula.value)
        subvalor = normalizar(sub.value)

        if valor or subvalor:
            print(
                f"    {celula.coordinate}: "
                f"linha 4={celivel(valor)}, linha 5={celivel(subvalor)}"
            )

def celivel(valor):
    return valor if valor else "(vazio)"

def main():
    if not ARQUIVO.exists():
        print(f"ERRO: arquivo não encontrado:\n{ARQUIVO}")
        return

    wb = load_workbook(
        ARQUIVO,
        keep_vba=True,
        data_only=False,
        read_only=True,
    )

    if ABA not in wb.sheetnames:
        print(f"ERRO: aba '{ABA}' não encontrada.")
        print("Abas disponíveis:", wb.sheetnames)
        wb.close()
        return

    ws = wb[ABA]

    print("=" * 65)
    print("VALIDAÇÃO DE DESTINOS — SOMENTE LEITURA")
    print(f"Arquivo: {ARQUIVO.name}")
    print(f"Aba: {ABA}")
    print(f"Dimensões: {ws.max_row} linhas x {ws.max_column} colunas")
    print("Linha 99: setembro | Linha 100: outubro (não alterar)")
    print("=" * 65)

    print("\n1. UCs INDIVIDUAIS")
    for uc in UCS_INDIVIDUAIS:
        locais = localizar_uc(ws, uc)
        if locais:
            print(f"  UC {uc}: {', '.join(locais)}")
            for local in locais:
                celula = ws[local]
                print(f"    Conteúdo de identificação: {celula.value}")
                mostrar_colunas(ws, celula.column)
        else:
            print(f"  UC {uc}: NÃO LOCALIZADA")

    print("\n2. BLOCOS DE CÂMERAS")
    for sigla in CAMERAS:
        locais = localizar_bloco_camera(ws, sigla)
        if not locais:
            print(f"  {sigla}: NÃO LOCALIZADO")
            continue

        print(f"  Bloco {sigla}: {', '.join(locais)}")
        for local in locais:
            celula = ws[local]
            print(f"    Identificação na linha {celula.row}: {celula.value}")
            mostrar_colunas(ws, celula.column)

    print("\n3. FÓRMULAS E VALORES NAS LINHAS 99 E 100")
    for sigla in CAMERAS:
        locais = localizar_bloco_camera(ws, sigla)
        if not locais:
            continue

        # Usa a coluna do primeiro local encontrado para exibir
        # as células do bloco nas duas linhas de referência.
        coluna = ws[locais[0]].column
        print(f"\n  {sigla}:")
        for deslocamento in range(15):
            col = coluna + deslocamento
            c99 = ws.cell(99, col)
            c100 = ws.cell(100, col)

            if c99.value is not None or c100.value is not None:
                print(
                    f"    {c99.column_letter}: "
                    f"linha 99={c99.value!r} | "
                    f"linha 100={c100.value!r}"
                )

    wb.close()
    print("\nDiagnóstico concluído. Nenhuma célula foi alterada.")

if __name__ == "__main__":
    main()
