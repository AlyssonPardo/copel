
from pathlib import Path
from collections import Counter
import json
import re

import openpyxl
from openpyxl.utils import get_column_letter

PASTA = Path(__file__).resolve().parent
PLANILHA = PASTA / "planilhas" / "teste automação.xlsm"
JSON = PASTA / "revisao" / "copel agp_principais.json"
SAIDA = PASTA / "revisao" / "mapa_ucs_setembro.txt"

IGNORAR = {"000655099603145"}

def main():
    if not PLANILHA.exists():
        raise FileNotFoundError(f"Planilha não encontrada: {PLANILHA}")
    if not JSON.exists():
        raise FileNotFoundError(f"JSON não encontrado: {JSON}")

    with JSON.open(encoding="utf-8") as f:
        faturas = json.load(f)

    wb = openpyxl.load_workbook(
        PLANILHA, read_only=False, data_only=False, keep_vba=True
    )
    ws = wb["COPEL"]

    ucs_planilha = {}
    for row in ws.iter_rows():
        for cell in row:
            if not isinstance(cell.value, str):
                continue
            for uc in re.findall(r"(?<!\d)\d{15}(?!\d)", cell.value):
                ucs_planilha.setdefault(
                    uc, (cell.coordinate, cell.value)
                )

    faturas_validas = [
        f for f in faturas
        if f.get("referencia") == "09/2026"
        and f.get("UC") not in IGNORAR
    ]

    linhas = [
        "MAPEAMENTO DE UCs — SETEMBRO/2026",
        f"Planilha: {PLANILHA.name}",
        f"Faturas consideradas: {len(faturas_validas)}",
        "",
    ]

    encontradas = 0
    pendentes = []

    for fatura in faturas_validas:
        uc = fatura["UC"]
        linhas.append(
            f"UC: {uc} | NF: {fatura.get('nota_fiscal')} "
            f"| Consumo: {fatura.get('consumo_ponta_kwh')} "
            f"| Fora ponta: {fatura.get('consumo_fora_ponta_kwh')}"
        )

        if uc in ucs_planilha:
            coord, texto = ucs_planilha[uc]
            linhas.append(f"  Encontrada em {coord}: {texto}")
            encontradas += 1
        else:
            linhas.append("  NÃO LOCALIZADA na aba COPEL")
            pendentes.append(uc)

        linhas.append("")

    linhas += [
        f"Total de faturas incluídas: {len(faturas_validas)}",
        f"UCs localizadas: {encontradas}",
        f"UCs não localizadas: {len(pendentes)}",
        "",
        "PENDENTES:",
        *pendentes,
    ]

    SAIDA.parent.mkdir(parents=True, exist_ok=True)
    SAIDA.write_text("\n".join(linhas), encoding="utf-8")

    print("\n".join(linhas))
    print(f"\nRelatório salvo em: {SAIDA}")
    wb.close()


if __name__ == "__main__":
    main()
