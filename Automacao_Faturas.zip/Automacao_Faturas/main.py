import json
import shutil
import sys
from datetime import datetime
from pathlib import Path

import pythoncom
import win32com.client as win32


# ============================================================
# CONFIGURAÇÃO
# ============================================================

BASE_DIR = Path(__file__).resolve().parent
REVISAO_DIR = BASE_DIR / "revisao"
ORIGINAL_XLSM = BASE_DIR / "planilhas" / "teste automação.xlsm"
ABA = "COPEL"
LINHA_INICIAL = 99
REFERENCIA_INICIAL = "09/2026"
MESES_AUTOMACAO = 60  # Setembro/2026 até agosto/2031
UC_EXCLUIDA = "000655099603145"


# ============================================================
# MAPEAMENTO DAS UCs INDIVIDUAIS
# ============================================================

INDIVIDUAIS = {
    "000107312903154": {
        "data": "AU", "nota": "AV", "consumo_ponta": "AX",
        "bandeira": "AZ", "valor_bandeira": "BA", "iluminacao": "BC",
        "valor_fatura": "BD", "COFINS": "BE", "CSLL": "BF", "IRPJ": "BG", "PIS": "BH",
    },
    "000089993503173": {
        "data": "BK", "nota": "BL", "consumo_ponta": "BN",
        "bandeira": "BP", "valor_bandeira": "BQ", "iluminacao": "BS",
        "valor_fatura": "BT", "COFINS": "BU", "CSLL": "BV", "IRPJ": "BW", "PIS": "BX",
    },
    "000290298603152": {
        "data": "JY", "nota": "JZ", "consumo_ponta": "JX",
        "bandeira": "KC", "valor_bandeira": "KD", "iluminacao": "KF",
        "valor_fatura": "KG", "COFINS": "KH", "CSLL": "KI", "IRPJ": "KJ", "PIS": "KK",
    },
    "000387264403105": {
        "data": "ZH", "nota": "ZI", "consumo_ponta": "ZK",
        "consumo_fora": "ZL", "demanda_medida": "ZM",
        "bandeira": "ZP", "valor_bandeira": "ZQ", "iluminacao": "ZS",
        "valor_fatura": "ZT", "COFINS": "ZU", "CSLL": "ZV", "IRPJ": "ZW", "PIS": "ZX",
    },
    "000259216303146": {
        "data": "HZ", "nota": "IA", "consumo_ponta": "HT",
        "consumo_fora": "HU", "demanda_medida": "HV",
        "bandeira": "ID", "valor_bandeira": "IE", "iluminacao": "IG",
        "valor_fatura": "IH", "COFINS": "II", "CSLL": "IJ", "IRPJ": "IK", "PIS": "IL",
    },
    "000172913003140": {
        "data": "CG", "nota": "CH", "consumo_ponta": "CA",
        "consumo_fora": "CB", "demanda_medida": "CC",
        "bandeira": "CK", "valor_bandeira": "CL", "iluminacao": "CN",
        "valor_fatura": "CP", "COFINS": "CQ", "CSLL": "CR", "IRPJ": "CS", "PIS": "CT",
    },
    "000092929903180": {
        "data": "EC", "nota": "ED", "consumo_ponta": "EF",
        "bandeira": "EH", "valor_bandeira": "EI", "iluminacao": "EK",
        "valor_fatura": "EL", "COFINS": "EM", "CSLL": "EN", "IRPJ": "EO", "PIS": "EP",
    },
    "000191504303106": {
        "data": "FI", "nota": "FJ", "consumo_ponta": "FL",
        "bandeira": "FN", "valor_bandeira": "FO", "iluminacao": "FQ",
        "valor_fatura": "FR", "COFINS": "FS", "CSLL": "FT", "IRPJ": "FU", "PIS": "FV",
    },
    "000080222403159": {
        "data": "AAQ", "nota": "AAR", "consumo_ponta": "AAT",
        "consumo_fora": "AAU", "demanda_medida": "AAV",
        "bandeira": "AAY", "valor_bandeira": "AAZ", "iluminacao": "ABB",
        "valor_fatura": "ABC", "COFINS": "ABD", "CSLL": "ABE", "IRPJ": "ABF", "PIS": "ABG",
    },
    "000148234203104": {
        "data": "ACP", "nota": "ACQ", "consumo_ponta": "ACS",
        "bandeira": "ACU", "valor_bandeira": "ACV", "iluminacao": "ACX",
        "valor_fatura": "ACY", "COFINS": "ACZ", "CSLL": "ADA", "IRPJ": "ADB", "PIS": "ADC",
    },
    "000490130003129": {
        "data": "JE", "nota": "JF", "consumo_ponta": "JH",
        "consumo_fora": "JI", "demanda_medida": "JJ",
        "bandeira": "JM", "valor_bandeira": "JN", "iluminacao": "JP",
        "valor_fatura": "JQ", "COFINS": "JR", "CSLL": "JS", "IRPJ": "JT", "PIS": "JU",
    },
    "000499193203182": {
        "data": "ABZ", "nota": "ACA", "consumo_ponta": "ACC",
        "bandeira": "ACE", "valor_bandeira": "ACF", "iluminacao": "ACH",
        "valor_fatura": "ACI", "COFINS": "ACJ", "CSLL": "ACK", "IRPJ": "ACL", "PIS": "ACM",
    },
    "000497982103131": {
        "data": "KN", "nota": "KO", "consumo_ponta": "KQ",
        "bandeira": "KS", "valor_bandeira": "KT", "iluminacao": "KV",
        "valor_fatura": "KW", "COFINS": "KX", "CSLL": "KY", "IRPJ": "KZ", "PIS": "LA",
    },
    "000452896103119": {
        "data": "ES", "nota": "ET", "consumo_ponta": "EV",
        "bandeira": "EX", "valor_bandeira": "EY", "iluminacao": "FA",
        "valor_fatura": "FB", "COFINS": "FC", "CSLL": "FD", "IRPJ": "FE", "PIS": "FF",
    },
    "000515038503116": {
        "data": "LD", "nota": "LE", "consumo_ponta": "LG",
        "bandeira": "LI", "valor_bandeira": "LJ", "iluminacao": "LL",
        "valor_fatura": "LM", "COFINS": "LN", "CSLL": "LO", "IRPJ": "LP", "PIS": "LQ",
    },
}


# ============================================================
# MAPEAMENTO DAS 22 CÂMERAS
# ============================================================

CAMERAS = [
    ("000517879703190", "LT"),
    ("000517881803101", "MJ"),
    ("000517884203104", "MZ"),
    ("000517884803144", "NP"),
    ("000517886903106", "OF"),
    ("000517888203129", "OV"),
    ("000517889403191", "PL"),
    ("000517894503146", "QB"),
    ("000517894603131", "QR"),
    ("000517894703127", "RH"),
    ("000517894903108", "RX"),
    ("000517895303147", "SN"),
    ("000517895803107", "TD"),
    ("000517896703190", "TT"),
    ("000517897903153", "UJ"),
    ("000517899603140", "UZ"),
    ("000517900403134", "VP"),
    ("000517901803188", "WF"),
    ("000517903303194", "WV"),
    ("000517905103177", "XL"),
    ("000517906603106", "YB"),
    ("000517908103112", "YR"),
]

CAMERA_OFFSETS = {
    "data": 0,
    "nota": 1,
    "consumo_ponta": 3,
    "bandeira": 5,
    "valor_bandeira": 6,
    "iluminacao": 8,
    "valor_fatura": 9,
    "COFINS": 10,
    "CSLL": 11,
    "IRPJ": 12,
    "PIS": 13,
}


# ============================================================
# FUNÇÕES AUXILIARES
# ============================================================

def parse_data(valor):
    if valor in (None, ""):
        return None
    if isinstance(valor, datetime):
        return valor
    return datetime.strptime(str(valor).strip(), "%d/%m/%Y")


def valor_para_excel(valor):
    if valor is None or valor == "":
        return None
    return valor


def definir(celula, valor):
    if valor is not None and valor != "":
        celula.Value = valor


def mapear_camera(inicio):
    from openpyxl.utils import column_index_from_string, get_column_letter

    base = column_index_from_string(inicio)

    return {
        campo: get_column_letter(base + deslocamento)
        for campo, deslocamento in CAMERA_OFFSETS.items()
    }


# ============================================================
# VALIDAÇÃO DO JSON
# ============================================================

def calcular_linha(referencia):
    """Calcula a linha com base em setembro/2026 = linha 99."""
    try:
        mes, ano = map(int, referencia.split("/"))
        data_ref = datetime(ano, mes, 1)
    except (ValueError, AttributeError):
        raise ValueError(
            f"Referência inválida: {referencia!r}. Use MM/AAAA, por exemplo 10/2026."
        )

    diferenca = (data_ref.year - 2026) * 12 + (data_ref.month - 9)

    if diferenca < 0 or diferenca >= MESES_AUTOMACAO:
        raise ValueError(
            f"A referência {referencia} está fora do período configurado "
            f"(09/2026 a 08/2031)."
        )

    return LINHA_INICIAL + diferenca


def validar_entrada(registros):
    if not isinstance(registros, list):
        raise ValueError("O JSON precisa conter uma lista de faturas.")

    filtrados = [
        r for r in registros
        if str(r.get("UC", "")).strip() != UC_EXCLUIDA
    ]

    referencias = {
        str(r.get("referencia", "")).strip()
        for r in filtrados
    }

    if len(referencias) != 1:
        raise ValueError(
            f"O JSON precisa conter uma única referência. Encontrei: {sorted(referencias)}"
        )

    referencia = next(iter(referencias))
    linha_destino = calcular_linha(referencia)

    ucs = [str(r.get("UC", "")).strip() for r in filtrados]
    duplicadas = sorted({uc for uc in ucs if ucs.count(uc) > 1})
    if duplicadas:
        raise ValueError(f"UCs duplicadas no JSON: {duplicadas}")

    esperadas = set(INDIVIDUAIS) | {uc for uc, _ in CAMERAS}
    recebidas = set(ucs)
    faltando = sorted(esperadas - recebidas)
    inesperadas = sorted(recebidas - esperadas)

    if faltando or inesperadas:
        raise ValueError(
            f"Conferência das UCs falhou. Faltando: {faltando}; "
            f"inesperadas: {inesperadas}"
        )

    if len(filtrados) != 37:
        raise ValueError(
            f"Esperava 37 UCs após excluir {UC_EXCLUIDA}, "
            f"mas encontrei {len(filtrados)}."
        )

    pendentes = [
        str(r.get("UC")) for r in filtrados
        if r.get("revisar_manual") is True
    ]
    if pendentes:
        raise ValueError(
            "Há registros marcados para revisão manual; não vou preencher "
            f"automaticamente essas UCs: {pendentes}"
        )

    return filtrados, referencia, linha_destino


# ============================================================
# PREENCHIMENTO DOS DADOS
# ============================================================

def preencher_registro(ws, registro, colunas, linha):

    if registro.get("data_emissao"):
        c = ws.Range(f'{colunas["data"]}{linha}')
        c.Value = parse_data(registro["data_emissao"])
        c.NumberFormat = "dd/mm/yyyy"

    definir(
        ws.Range(f'{colunas["nota"]}{linha}'),
        valor_para_excel(registro.get("nota_fiscal"))
    )

    if "consumo_ponta" in colunas:
        definir(
            ws.Range(f'{colunas["consumo_ponta"]}{linha}'),
            valor_para_excel(registro.get("consumo_ponta_kwh"))
        )

    if "consumo_fora" in colunas:
        definir(
            ws.Range(f'{colunas["consumo_fora"]}{linha}'),
            valor_para_excel(registro.get("consumo_fora_ponta_kwh"))
        )

    # A planilha possui uma única coluna de demanda medida.
    # Prioriza PT; se não houver, usa FP; se não houver nenhum dos dois, usa TP.
    if "demanda_medida" in colunas:
        demanda = registro.get("demanda_medida_ponta_kw")
        if demanda is None:
            demanda = registro.get("demanda_medida_fora_ponta_kw")
        if demanda is None:
            demanda = registro.get("demanda_medida_todos_periodos_kw")
        definir(ws.Range(f'{colunas["demanda_medida"]}{linha}'), valor_para_excel(demanda))

    campos_json = {
        "bandeira": "bandeira",
        "valor_bandeira": "valor_bandeira",
        "iluminacao": "iluminacao_publica",
        "valor_fatura": "valor_fatura",
        "COFINS": "COFINS",
        "CSLL": "CSLL",
        "IRPJ": "IRPJ",
        "PIS": "PIS",
    }

    for campo_planilha, campo_json in campos_json.items():

        definir(
            ws.Range(f'{colunas[campo_planilha]}{linha}'),
            valor_para_excel(registro.get(campo_json))
        )


# ============================================================
# EXECUÇÃO PRINCIPAL
# ============================================================

def selecionar_json():
    """Localiza os JSONs e permite escolher a referência quando há mais de uma."""
    arquivos = sorted(REVISAO_DIR.glob("*_principais.json"))
    encontrados = []
    for caminho in arquivos:
        try:
            dados = json.loads(caminho.read_text(encoding="utf-8-sig"))
            if not isinstance(dados, list) or not dados:
                continue
            refs = {str(r.get("referencia", "")).strip() for r in dados if r.get("referencia")}
            if len(refs) == 1:
                referencia = next(iter(refs))
                # Só considera referências dentro da janela configurada.
                calcular_linha(referencia)
                encontrados.append((referencia, caminho))
        except Exception as erro:
            print(f"Ignorando {caminho.name}: {erro}")
    if not encontrados:
        raise FileNotFoundError(
            f"Nenhum JSON válido encontrado em {REVISAO_DIR}. Execute extrair_fatura.py primeiro."
        )
    # Se existem arquivos diferentes para a mesma referência, não escolhe silenciosamente.
    opcoes = sorted(encontrados, key=lambda item: (
        int(item[0].split("/")[1]), int(item[0].split("/")[0]), item[1].name
    ))
    if len(opcoes) == 1:
        return opcoes[0][1]
    print("\nForam encontrados JSONs para estas referências:")
    for i, (ref, caminho) in enumerate(opcoes, start=1):
        print(f"{i}. {ref} - {caminho.name}")
    escolha = input("Digite o número da referência que deseja preencher: ").strip()
    if not escolha.isdigit() or not (1 <= int(escolha) <= len(opcoes)):
        raise ValueError("Seleção inválida. Nenhuma planilha foi alterada.")
    return opcoes[int(escolha) - 1][1]


def main():

    if not REVISAO_DIR.exists():
        raise FileNotFoundError(f"Pasta de revisão não encontrada: {REVISAO_DIR}")

    if not ORIGINAL_XLSM.exists():
        raise FileNotFoundError(
            f"Planilha original não encontrada: {ORIGINAL_XLSM}"
        )

    JSON_PATH = selecionar_json()
    with JSON_PATH.open("r", encoding="utf-8-sig") as arquivo:
        registros, referencia, linha_destino = validar_entrada(json.load(arquivo))

    nome_referencia = referencia.replace("/", "-")
    OUTPUT_XLSM = BASE_DIR / "planilhas" / f"teste automação_{nome_referencia}_preenchida.xlsm"

    # Sempre recria a cópia a partir do original.
    # O arquivo original nunca é alterado.
    OUTPUT_XLSM.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ORIGINAL_XLSM, OUTPUT_XLSM)

    pythoncom.CoInitialize()

    excel = None
    wb = None

    try:

        excel = win32.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False
        excel.EnableEvents = False
        excel.ScreenUpdating = False

        wb = excel.Workbooks.Open(
            str(OUTPUT_XLSM.resolve()),
            UpdateLinks=0,
            ReadOnly=False
        )

        ws = wb.Worksheets(ABA)

        # Guarda as fórmulas monitoradas antes de preencher.
        formulas_antes = {}

        from openpyxl.utils import (
            column_index_from_string,
            get_column_letter
        )

        for uc, inicio in CAMERAS:

            base = column_index_from_string(inicio)

            for desloc in (4, 14):

                letra = get_column_letter(base + desloc)

                for linha in (linha_destino,):

                    endereco = f"{letra}{linha}"

                    formulas_antes[endereco] = ws.Range(endereco).Formula

        formulas_individuais = {
            "000107312903154": ("AY", "BI"),
            "000089993503173": ("BO", "BY"),
            "000290298603152": ("KB", "KL"),
            "000387264403105": ("ZO", "ZY"),
            "000259216303146": ("IC", "IM"),
            "000172913003140": ("CJ", "CU"),
            "000092929903180": ("EG", "EQ"),
            "000191504303106": ("FM", "FW"),
            "000080222403159": ("AAX", "ABH"),
            "000148234203104": ("ACT", "ADD"),
            "000490130003129": ("JL", "JV"),
            "000499193203182": ("ACD", "ACN"),
            "000497982103131": ("KR", "LB"),
            "000452896103119": ("EW", "FG"),
            "000515038503116": ("LH", "LR"),
        }

        for letras in formulas_individuais.values():

            for letra in letras:

                for linha in (linha_destino,):

                    endereco = f"{letra}{linha}"

                    formulas_antes[endereco] = ws.Range(endereco).Formula

        por_uc = {
            str(r["UC"]).strip(): r
            for r in registros
        }

        # Não sobrescreve uma referência já lançada na linha de destino.
        notas_destino = []
        for colunas in INDIVIDUAIS.values():
            endereco = f'{colunas["nota"]}{linha_destino}'
            if ws.Range(endereco).Value not in (None, ""):
                notas_destino.append(endereco)
        for uc, inicio in CAMERAS:
            coluna_nota = mapear_camera(inicio)["nota"]
            endereco = f"{coluna_nota}{linha_destino}"
            if ws.Range(endereco).Value not in (None, ""):
                notas_destino.append(endereco)
        if notas_destino:
            raise RuntimeError(
                f"A linha {linha_destino} já contém notas fiscais ({', '.join(notas_destino[:8])}). "
                "Não vou sobrescrever dados existentes. Confira a planilha original."
            )

        gravacoes = 0
        verificacoes = []

        # Preenche as 15 UCs individuais.
        for uc, colunas in INDIVIDUAIS.items():

            registro = por_uc[uc]

            preencher_registro(ws, registro, colunas, linha_destino)

            gravacoes += 1

            if (
                "consumo_fora" in colunas
                and registro.get("consumo_fora_ponta_kwh") is not None
            ):
                verificacoes.append((
                    f'{colunas["consumo_fora"]}{linha_destino}',
                    registro["consumo_fora_ponta_kwh"]
                ))

            if "demanda_medida" in colunas:
                demanda_verificar = registro.get("demanda_medida_ponta_kw")
                if demanda_verificar is None:
                    demanda_verificar = registro.get("demanda_medida_fora_ponta_kw")
                if demanda_verificar is None:
                    demanda_verificar = registro.get("demanda_medida_todos_periodos_kw")
                if demanda_verificar is not None:
                    verificacoes.append((
                        f'{colunas["demanda_medida"]}{linha_destino}',
                        demanda_verificar
                    ))

        # Preenche as 22 câmeras.
        for uc, inicio in CAMERAS:

            preencher_registro(
                ws,
                por_uc[uc],
                mapear_camera(inicio),
                linha_destino
            )

            gravacoes += 1

        # ====================================================
        # VALORES CONFIRMADOS DIRETAMENTE NAS FATURAS
        # ====================================================

        # Ajustes manuais confirmados exclusivamente para 09/2026.
        # Não repetir esses valores nos meses seguintes.
        if referencia == "09/2026":
            ws.Range(f"CD{linha_destino}").Value = 735.84
            verificacoes.append((f"CD{linha_destino}", 735.84))

            ws.Range(f"CO{linha_destino}").Value = 24770.66
            verificacoes.append((f"CO{linha_destino}", 24770.66))

            ws.Range(f"JJ{linha_destino}").Value = 9.49
            verificacoes.append((f"JJ{linha_destino}", 9.49))

        # ====================================================
        # CONFERÊNCIA DOS VALORES
        # ====================================================

        erros_valores = []

        for endereco, esperado in verificacoes:

            obtido = ws.Range(endereco).Value

            if (
                obtido is None
                or abs(float(obtido) - float(esperado)) > 0.000001
            ):
                erros_valores.append(
                    f"{endereco}: esperado {esperado}, encontrado {obtido}"
                )

        if erros_valores:
            raise RuntimeError(
                "Falha na conferência dos dados: "
                + "; ".join(erros_valores)
            )

        # ====================================================
        # CONFERE FÓRMULAS E LINHA DE OUTUBRO
        # ====================================================

        alteracoes_formula = []

        for endereco, formula_antes in formulas_antes.items():

            formula_depois = ws.Range(endereco).Formula

            if formula_depois != formula_antes:
                alteracoes_formula.append(endereco)

        if alteracoes_formula:

            raise RuntimeError(
                "A verificação detectou alteração em fórmulas protegidas: "
                + ", ".join(alteracoes_formula)
            )

        # Salva somente depois das verificações.
        wb.Save()

        print("\nAUTOMAÇÃO CONCLUÍDA COM SUCESSO")
        print(f"UCs preenchidas: {gravacoes} de 37")
        print(f"Referência: {referencia} (linha {linha_destino})")
        print(f"UC excluída: {UC_EXCLUIDA}")
        if referencia == "09/2026":
            print(f"Valores especiais de setembro conferidos na linha {linha_destino}.")
        print("Valores-chave conferidos diretamente no Excel.")
        print("Fórmulas da linha de destino monitoradas e preservadas.")
        print(f"JSON utilizado: {JSON_PATH.name}")
        print(f"Arquivo gerado: {OUTPUT_XLSM}")

    except Exception:

        if wb is not None:

            try:
                wb.Close(SaveChanges=False)
            except Exception:
                pass

            wb = None

        raise

    finally:

        if wb is not None:
            wb.Close(SaveChanges=False)

        if excel is not None:
            excel.Quit()

        pythoncom.CoUninitialize()


if __name__ == "__main__":

    try:
        main()

    except Exception as erro:

        print(f"ERRO: {erro}", file=sys.stderr)
        sys.exit(1)