
from pathlib import Path
from pypdf import PdfReader

arquivo = Path("faturas") / "copel agp.pdf"

if not arquivo.exists():
    print(f"PDF não encontrado: {arquivo}")
    raise SystemExit(1)

leitor = PdfReader(str(arquivo))

# Páginas das faturas de baixo consumo e de alta tensão
paginas_alvo = [5, 7, 17, 21]

pasta_saida = Path("revisao")
pasta_saida.mkdir(exist_ok=True)

saida = pasta_saida / "diagnostico_layout.txt"

with saida.open("w", encoding="utf-8") as f:
    for numero in paginas_alvo:
        pagina = leitor.pages[numero - 1]

        f.write(f"\n{'=' * 25} PÁGINA {numero} {'=' * 25}\n")

        try:
            texto = pagina.extract_text(
                extraction_mode="layout"
            ) or ""
        except Exception as erro:
            texto = pagina.extract_text() or ""
            f.write(f"Observação: fallback de extração ({erro})\n")

        f.write(texto)
        f.write("\n")

print(f"Diagnóstico salvo em: {saida}")
print(f"Páginas analisadas: {', '.join(map(str, paginas_alvo))}")
