import csv
import json
import re
from pathlib import Path
from pypdf import PdfReader

BASE_DIR = Path(__file__).resolve().parent
PASTA_FATURAS = BASE_DIR / "faturas"
PASTA_REVISAO = BASE_DIR / "revisao"

PASTA_FATURAS.mkdir(exist_ok=True)
PASTA_REVISAO.mkdir(exist_ok=True)


def valor_br(texto):
    if not texto:
        return None
    try:
        return float(texto.replace(".", "").replace(",", "."))
    except (ValueError, AttributeError):
        return None


def buscar(padrao, texto):
    resultado = re.search(padrao, texto, re.I | re.M)
    return resultado.group(1).strip() if resultado else None


def valores_linha(linha):
    padrao = r"-?\d{1,3}(?:\.\d{3})+,\d{2}|-?\d+,\d{2}"
    return [valor_br(v) for v in re.findall(padrao, linha)]


def extrair_imposto(texto, nome):
    encontrados = set()
    for linha in texto.splitlines():
        if not re.search(r"IMP\s*\.?\s*RET\s*\.?", linha, re.I):
            continue
        if not re.search(nome, linha, re.I):
            continue
        valores = valores_linha(linha)
        if valores:
            encontrados.add(round(abs(valores[-1]), 2))
    return round(sum(encontrados), 2) if encontrados else None


def extrair_referencia(texto):
    """Identifica a referência da fatura, sem fixar um mês específico."""
    # Formato recorrente nas faturas Copel: MM/AAAA + data de vencimento/emissão + R$.
    padroes = [
        r"\b(0[1-9]|1[0-2])/(20\d{2})\s+\d{2}/\d{2}/\d{4}\s+R\$",
        r"(?:M[EÊ]S|REFER[EÊ]NCIA)\s*(?:DE)?\s*:?\s*(0[1-9]|1[0-2])/(20\d{2})",
    ]
    for padrao in padroes:
        resultado = re.search(padrao, texto, re.I)
        if resultado:
            return f"{resultado.group(1)}/{resultado.group(2)}"
    return None


def extrair_consumos(texto):
    ponta = None
    fora_ponta = None

    for linha in texto.splitlines():
        if not re.search(r"CONSUMO\s+kWh", linha, re.I):
            continue
        tipo = re.search(r"\b(PT|FP|TP)\b", linha, re.I)
        if not tipo:
            continue
        tipo = tipo.group(1).upper()
        if tipo == "TP":
            continue

        quantidade = re.search(r"(\d[\d.]*)\s*$", linha)
        if not quantidade:
            continue
        numero = int(quantidade.group(1).replace(".", ""))

        if tipo == "PT":
            ponta = numero
        elif tipo == "FP":
            fora_ponta = numero

    if ponta is None and fora_ponta is None:
        referencia = extrair_referencia(texto)
        if referencia:
            mes, ano = map(int, referencia.split("/"))
            meses = ["JAN", "FEV", "MAR", "ABR", "MAI", "JUN",
                     "JUL", "AGO", "SET", "OUT", "NOV", "DEZ"]
            codigo = f"{meses[mes - 1]}{str(ano)[-2:]}"
            historico = re.search(rf"\b{codigo}\s+(\d+)\b", texto, re.I)
            if historico:
                ponta = int(historico.group(1))

    return ponta, fora_ponta


def extrair_demanda_medida(texto):
    """Extrai os valores por posto horário das linhas DEMANDA kW."""
    resultado = {"PT": None, "FP": None, "TP": None}
    for linha in texto.splitlines():
        if not re.search(r"\bDEMANDA\s+kW\b", linha, re.I):
            continue
        tipo = re.search(r"\b(PT|FP|TP)\b", linha, re.I)
        if not tipo:
            continue
        numeros = re.findall(r"(?<![\w])\d+(?:\.\d+)?", linha)
        decimais = []
        for item in numeros:
            if "." in item:
                try:
                    decimais.append(float(item))
                except ValueError:
                    pass
        if decimais:
            resultado[tipo.group(1).upper()] = round(decimais[-1], 2)
    return resultado


def extrair_bandeira(texto):
    padrao = (
        r"Periodos\s+Band\s*\.?\s*Tarif\s*\.?\s*:"
        r".{0,100}?\b(Amarela|Vermelha|Verde)\b"
    )
    resultado = re.search(padrao, texto, re.I | re.S)
    if resultado:
        return resultado.group(1).capitalize()

    for linha in texto.splitlines():
        if re.search(r"BAND", linha, re.I):
            resultado = re.search(r"\b(Amarela|Vermelha|Verde)\b", linha, re.I)
            if resultado:
                return resultado.group(1).capitalize()
    return None


def extrair_valor_bandeira(texto):
    total = 0.0
    encontrou = False

    for linha in texto.splitlines():
        if re.search(r"ADICIONAL\s+BAND", linha, re.I):
            padrao = (
                r"\bkWh\s+"
                r"[\d.]+,\d{2}\s+"
                r"[\d.]+,\d{3,6}\s+"
                r"([\d.]+,\d{2})"
            )
            resultado = re.search(padrao, linha, re.I)
            if resultado:
                valor = valor_br(resultado.group(1))
                if valor is not None:
                    total += valor
                    encontrou = True
        elif re.search(r"ENERGIA\s+CONS\.\s+B\.", linha, re.I):
            numeros = re.findall(r"\d[\d.]*,\d{2,6}", linha)
            if len(numeros) >= 3:
                valor = valor_br(numeros[2])
                if valor is not None:
                    total += valor
                    encontrou = True

    return round(total, 2) if encontrou else None


def extrair_iluminacao(texto):
    for linha in texto.splitlines():
        if re.search(
            r"CONT\s*\.?\s*IL\s*\.?\s*PUB|CONT\s+ILUMIN\s+PUBLICA|CIP\s+MUNICIPAL",
            linha,
            re.I,
        ):
            valores = valores_linha(linha)
            if valores:
                return round(abs(valores[-1]), 2)
    return 0.0


def extrair_valor_fatura(texto, referencia):
    if not referencia:
        return None
    padrao = (
        rf"\b{re.escape(referencia)}\s+"
        r"\d{2}/\d{2}/\d{4}\s+R\$\s*([\d.]+,\d{2})"
    )
    resultado = re.search(padrao, texto, re.I)
    if resultado:
        return valor_br(resultado.group(1))

    for linha in texto.splitlines():
        if re.search(rf"\b{re.escape(referencia)}\b", linha):
            resultado = re.search(r"R\$\s*([\d.]+,\d{2})", linha, re.I)
            if resultado:
                return valor_br(resultado.group(1))
    return None


def extrair_fatura(pagina, texto):
    nota = buscar(
        r"NOTA\s+FISCAL\s*(?:N\s*(?:[º°]|O\.?|\.)?\s*)?(\d{6,})",
        texto,
    )
    if not nota:
        return None

    uc = buscar(r"\b(\d{15})\b", texto)
    emissao = buscar(
        r"DATA\s+DE\s+EMISSÃO\s*:?\s*(\d{2}/\d{2}/\d{4})",
        texto,
    )

    referencia = extrair_referencia(texto)

    ponta, fora_ponta = extrair_consumos(texto)
    demandas = extrair_demanda_medida(texto)
    bandeira = extrair_bandeira(texto)
    total_bandeira = extrair_valor_bandeira(texto)

    # Bandeira Verde não possui valor adicional.
    if bandeira == "Verde":
        total_bandeira = 0.0

    iluminacao = extrair_iluminacao(texto)
    valor_fatura = extrair_valor_fatura(texto, referencia)

    dados = {
        "pagina": pagina,
        "nota_fiscal": nota,
        "UC": uc,
        "referencia": referencia,
        "data_emissao": emissao,
        "consumo_ponta_kwh": ponta,
        "consumo_fora_ponta_kwh": fora_ponta,
        "demanda_medida_ponta_kw": demandas["PT"],
        "demanda_medida_fora_ponta_kw": demandas["FP"],
        "demanda_medida_todos_periodos_kw": demandas["TP"],
        "bandeira": bandeira,
        "valor_bandeira": total_bandeira,
        "iluminacao_publica": iluminacao,
        "valor_fatura": valor_fatura,
        "COFINS": extrair_imposto(texto, r"\bCOFINS\b"),
        "CSLL": extrair_imposto(texto, r"\bCSLL\b"),
        "IRPJ": extrair_imposto(texto, r"\bIRPJ\b"),
        "PIS": extrair_imposto(texto, r"\bPIS\b"),
    }

    dados["revisar_manual"] = any([
        not uc,
        not emissao,
        not referencia,
        valor_fatura is None,
        bandeira is None,
        total_bandeira is None,
        ponta is None and fora_ponta is None,
    ])
    return dados


def processar_pasta():
    arquivos = sorted(
        p for p in PASTA_FATURAS.iterdir()
        if p.is_file() and p.suffix.lower() == ".pdf"
    )

    if not arquivos:
        print("Nenhum PDF encontrado na pasta faturas.")
        return

    colunas = [
        "pagina", "nota_fiscal", "UC", "referencia",
        "data_emissao", "consumo_ponta_kwh",
        "consumo_fora_ponta_kwh", "demanda_medida_ponta_kw",
        "demanda_medida_fora_ponta_kw", "demanda_medida_todos_periodos_kw",
        "bandeira", "valor_bandeira", "iluminacao_publica",
        "valor_fatura", "COFINS", "CSLL", "IRPJ", "PIS",
        "revisar_manual",
    ]

    for arquivo in arquivos:
        leitor = PdfReader(str(arquivo))
        faturas = []

        for numero, pagina in enumerate(leitor.pages, start=1):
            try:
                texto = pagina.extract_text(extraction_mode="layout") or ""
            except Exception:
                texto = pagina.extract_text() or ""

            dados = extrair_fatura(numero, texto)
            if dados:
                faturas.append(dados)

        caminho_csv = PASTA_REVISAO / f"{arquivo.stem}_principais.csv"
        caminho_json = PASTA_REVISAO / f"{arquivo.stem}_principais.json"

        with caminho_csv.open("w", newline="", encoding="utf-8-sig") as arquivo_csv:
            escritor = csv.DictWriter(
                arquivo_csv,
                fieldnames=colunas,
                delimiter=";",
            )
            escritor.writeheader()
            escritor.writerows(faturas)

        caminho_json.write_text(
            json.dumps(faturas, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        sem_uc = sum(not f["UC"] for f in faturas)
        sem_valor = sum(f["valor_fatura"] is None for f in faturas)
        revisar = sum(f["revisar_manual"] for f in faturas)

        print(f"\nArquivo: {arquivo.name}")
        print(f"Total de páginas: {len(leitor.pages)}")
        print(f"Faturas principais: {len(faturas)}")
        print(f"CSV gerado: {caminho_csv}")
        print(f"JSON gerado: {caminho_json}")
        print(f"Faturas sem UC: {sem_uc}")
        print(f"Faturas sem valor: {sem_valor}")
        print(f"Faturas para revisão: {revisar}")

        for fatura in faturas:
            print(
                f"UC {fatura['UC']}: "
                f"demanda_PT={fatura['demanda_medida_ponta_kw']} | "
                f"demanda_FP={fatura['demanda_medida_fora_ponta_kw']} | "
                f"demanda_TP={fatura['demanda_medida_todos_periodos_kw']}"
            )

        print("A planilha Excel não foi alterada.")


if __name__ == "__main__":
    processar_pasta()
